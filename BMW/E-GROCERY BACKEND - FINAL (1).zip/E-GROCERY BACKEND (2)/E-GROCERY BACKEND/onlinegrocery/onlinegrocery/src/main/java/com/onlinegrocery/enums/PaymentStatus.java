package com.onlinegrocery.enums;

public enum PaymentStatus {
	
	INITIATED,
	SUCCESS,
	FAILED
}