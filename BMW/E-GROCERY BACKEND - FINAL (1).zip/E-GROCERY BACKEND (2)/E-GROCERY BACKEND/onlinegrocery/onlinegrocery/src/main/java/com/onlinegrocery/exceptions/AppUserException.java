package com.onlinegrocery.exceptions;

public class AppUserException extends Exception{
	public AppUserException(String msg) {
		super(msg);
	}
}
