package com.onlinegrocery.serviceImpl;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.onlinegrocery.dto.ProductDto;
import com.onlinegrocery.entity.Product;
import com.onlinegrocery.enums.Category;
import com.onlinegrocery.repo.ProductRepo;
import com.onlinegrocery.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepo productRepo;
	
	
	@Override
	public Product addProduct(String proudctName,String description,double price,byte[] image,Category category,int stockQuantity ,String base64Image) {
		// TODO Auto-generated method stub
		Product products = new Product();
		products.setProductName(proudctName);
		products.setDescription(description);
		products.setImage(image);
		products.setCategory(category);
		products.setPrice(price);
		products.setStockQuantity(stockQuantity);
		//products.setBase64Image(base64Image);
		return productRepo.save(products);
		
	}

	@Override
	public String deleteProduct(int productId) {
		productRepo.deleteById(productId);
		return "Product deleted successfully";
	}


	@Override
	public List<Product> getAllProducts() {
		 List<Product> products = productRepo.findAll();
		    for (Product product : products) {
		      byte[] imageData = product.getImage(); // Fetch image data from the database
		      if (imageData != null) {
		        String base64Image = Base64.getEncoder().encodeToString(imageData); // Convert to Base64
		        product.setBase64Image(base64Image); // Set the Base64-encoded image data in the Product object
		      }
		    }
		    return products;
		}

	@Override
	public List<Product> getProductByCategory(Category category) {
		return productRepo.findByCategory(category);
	}


	@Override
	public Product getById(int productId) {
		return productRepo.findById(productId).orElseThrow();
	}


//	@Override
//	public String updateProduct(ProductDto products, int productid) {
//		Optional<Product> optionalProduct = productRepo.findById(productid);
//      if (optionalProduct.isPresent()) {
//          Product productEntity = optionalProduct.get();
//          // Update the fields of the product with the values from the DTO
//          productEntity.setProductId(products.getProductId());
//          productEntity.setProductName(products.getProductName());
//          productEntity.setDescription(products.getDescription());
//          productEntity.setCategory(products.getCategory());
//          productEntity.setImage(products.getImage());
//          productEntity.setPrice(products.getPrice());
//          productEntity.setStockQuantity(products.getStockQuantity());
//          // Save the updated product
//          productRepo.save(productEntity);
//          return "Product updated successfully.";
//      } else {
//          return "Product not found.";
//      }
//	}
	
	 @Override
	    public boolean isProductAvailable(int productId) {
	        Product product = productRepo.findById(productId).orElseThrow();
	        return product != null && product.getStockQuantity() > 0;
	    }

	    @Override
	    public boolean updateProductStock(int productId, int quantity) {
	        Product product = productRepo.findById(productId).orElse(null);
	        if (product != null && product.getStockQuantity() >= quantity) {
	            product.setStockQuantity(product.getStockQuantity() - quantity);
	            productRepo.save(product);
	            return true;
	        } else {
	            return false;
	        }
	    }
	    @Override
	    public Product updateProduct( String productName, String description, double price, byte[] image, Category category, int stockQuantity, String base64Image,int productId) {
	        // Find the existing product by productId from the database
	        Optional<Product> optionalProduct = productRepo.findById(productId);
	        if (optionalProduct.isPresent()) {
	            Product product = optionalProduct.get();
	            // Update the product properties
	            product.setProductName(productName);
	            product.setDescription(description);
	            product.setPrice(price);
	            product.setImage(image);
	            product.setCategory(category);
	            product.setStockQuantity(stockQuantity);
	            //product.setBase64Image(base64Image);
	            return productRepo.save(product);
	        } else {
	            // Handle case when the product with the given productId is not found
	            throw new IllegalArgumentException("Product with productId " + productId + " not found");
	        }
	    }


}
