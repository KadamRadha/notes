package com.onlinegrocery.enums;

public enum PaymentType {
 CASH,UPI,CARD
 
}
