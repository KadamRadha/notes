package com.onlinegrocery.enums;

public enum Status {
	
    PLACED,

    SHIPPED,

    ONTHEWAY,

    PICKDUP,
	
	DELIVERED;

	
	

	
		
    
}

