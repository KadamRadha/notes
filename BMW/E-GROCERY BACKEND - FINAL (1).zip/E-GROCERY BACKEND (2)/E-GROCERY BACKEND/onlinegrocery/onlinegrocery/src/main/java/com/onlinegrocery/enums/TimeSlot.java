package com.onlinegrocery.enums;

public enum TimeSlot {
	MORNING,
	AFTERNOON,
	EVENING;
}
