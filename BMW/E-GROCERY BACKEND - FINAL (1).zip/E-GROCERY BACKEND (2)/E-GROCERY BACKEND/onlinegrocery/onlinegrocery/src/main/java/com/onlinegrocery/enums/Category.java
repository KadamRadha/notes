package com.onlinegrocery.enums;

public enum Category {
	VEGETABLES,
	FRUITS,
	GRAINS,
	DAIRY,
	MEAT,
	SEAFOOD,
	OTHER
}
