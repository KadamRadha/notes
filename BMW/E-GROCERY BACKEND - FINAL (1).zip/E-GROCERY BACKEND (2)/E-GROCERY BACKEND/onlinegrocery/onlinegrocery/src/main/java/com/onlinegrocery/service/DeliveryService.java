package com.onlinegrocery.service;

import com.onlinegrocery.dto.DeliveryDto;

public interface DeliveryService {
	
	public DeliveryDto addDeliverySlots(DeliveryDto deliverydto);


}
