package com.onlinegrocery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.onlinegrocery.dto.CartDto;
import com.onlinegrocery.entity.Cart;
import com.onlinegrocery.service.CartService;



@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@PostMapping("/add-cart")
	public ResponseEntity<Cart> addItemToCart(@RequestBody CartDto cartDTO) {
		return new ResponseEntity<Cart>(cartService.addItemToCart(cartDTO),HttpStatus.OK);
	}
	
	@PutMapping("/update-cart")
	public ResponseEntity<Cart> updateItemToCart(@RequestParam long cartId, @RequestBody CartDto cartDTO) {
		return new ResponseEntity<Cart>(cartService.updateItemToCart(cartId,cartDTO),HttpStatus.OK);
	}
	
	@DeleteMapping("/delete-cart")
	public ResponseEntity<String> deleteItemFromCart(@RequestParam long cartId) {
		cartService.deleteItemFromCart(cartId);
		return new ResponseEntity<String>("deleted", HttpStatus.OK);
	}

	@GetMapping("/get-cart-by-id")
	public ResponseEntity<Cart> getCartById(@RequestParam long cartId) {
		return new ResponseEntity<Cart>(cartService.getCartById(cartId),HttpStatus.OK);
	}
	@GetMapping("/get-all-cart")
	public List<Cart> getAllCartItems() {
		return cartService.getAllCartItems();
	}
}
