package com.onlinegrocery.exceptions;

public class WishlistNotFoundException  extends RuntimeException{

	public WishlistNotFoundException(String message) {
		super(message);
	}
	

}