package com.onlinegrocery.service;

import java.util.List;

import com.onlinegrocery.dto.CartDto;
import com.onlinegrocery.entity.Cart;



public interface CartService {
	
	Cart addItemToCart(CartDto cartDTO );
	
	Cart updateItemToCart(long cartId, CartDto cartDTO);

	String deleteItemFromCart(long cartId);
	
	Cart getCartById(long cartId);

	List<Cart> getAllCartItems();
	
	
}
