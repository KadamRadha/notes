package com.onlinegrocery.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.onlinegrocery.enums.PaymentType;
import com.onlinegrocery.enums.Status;


@Entity
@Table(name= "orders")
public class Order { 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long orderId;
	 @ManyToOne
	    @JoinColumn(name = "userId", nullable = false)
	    private AppUser user;
	private double totalAmount;
	private Date orderDate;
	private Status status;
	private PaymentType paymentType;
	 @ManyToOne
	  @JoinColumn(name = "address_id")
	  private Address address;
	 private String userName;

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Order(Long orderId, AppUser user, double totalAmount, Date orderDate, Status status, PaymentType paymentType,
			Address address) {
		super();
		this.orderId = orderId;
		this.user = user;
		this.totalAmount = totalAmount;
		this.orderDate = orderDate;
		this.status = status;
		this.paymentType = paymentType;
		this.address = address;

	}
	public Order() {
		super();
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public AppUser getUser() {
		return user;
	}
	public void setUser(AppUser user) {
		this.user = user;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public PaymentType getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}
	public Address getAddress(Address address2) {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", user=" + user + ", totalAmount=" + totalAmount + ", orderDate="
				+ orderDate + ", status=" + status + ", paymentType=" + paymentType + ", address=" + address
				+ "]";
	}
	public void setOrderId(Order order3) {
		// TODO Auto-generated method stub
		
	}

	 
	
}
	