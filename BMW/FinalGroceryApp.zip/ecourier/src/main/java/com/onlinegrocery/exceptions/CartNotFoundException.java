package com.onlinegrocery.exceptions;

public class CartNotFoundException extends RuntimeException {

	public CartNotFoundException(String msg) {
		super(msg);
		
	}
	

}