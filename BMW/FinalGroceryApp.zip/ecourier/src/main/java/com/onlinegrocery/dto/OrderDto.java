package com.onlinegrocery.dto;

import java.util.Date;

import com.onlinegrocery.enums.PaymentType;
import com.onlinegrocery.enums.Status;



public class OrderDto {
	private Long orderId;
	private double totalAmount;
	private Date orderDate;
	private Status status;
	private long addressId;
	private int userId;
	private PaymentType paymentType;
	private String userName;
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public long getAddressId() {
		return addressId;
	}
	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public PaymentType getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public OrderDto(Long orderId, double totalAmount, Date orderDate, Status status, long addressId, int userId,
			PaymentType paymentType, String userName) {
		super();
		this.orderId = orderId;
		this.totalAmount = totalAmount;
		this.orderDate = orderDate;
		this.status = status;
		this.addressId = addressId;
		this.userId = userId;
		this.paymentType = paymentType;
		this.userName = userName;
	}
	public OrderDto() {
		super();
	}
	public OrderDto(Long orderId2, String userName2, double totalAmount2, Date orderDate2, Status status2) {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "OrderDto [orderId=" + orderId + ", totalAmount=" + totalAmount + ", orderDate=" + orderDate
				+ ", status=" + status + ", addressId=" + addressId + ", userId=" + userId + ", paymentType="
				+ paymentType + ", userName=" + userName + "]";
	}
	
	
}
