package com.onlinegrocery.exceptions;

public class AddressNotFoundException extends Exception {

	public AddressNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
