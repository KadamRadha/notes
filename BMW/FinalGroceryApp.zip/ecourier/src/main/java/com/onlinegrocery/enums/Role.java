package com.onlinegrocery.enums;

public enum Role {
ADMIN,
CUSTOMER
}
