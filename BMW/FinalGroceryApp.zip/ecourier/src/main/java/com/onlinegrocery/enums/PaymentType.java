package com.onlinegrocery.enums;

public enum PaymentType {
 CARD,CASH,UPI
 
}
