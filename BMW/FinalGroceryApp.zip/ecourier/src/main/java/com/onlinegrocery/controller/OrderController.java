package com.onlinegrocery.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.onlinegrocery.dto.AddressDto;
import com.onlinegrocery.dto.OrderDto;
import com.onlinegrocery.entity.Address;
import com.onlinegrocery.entity.AppUser;
import com.onlinegrocery.entity.Order;
import com.onlinegrocery.enums.Status;
import com.onlinegrocery.exceptions.OrderNotFoundException;
import com.onlinegrocery.exceptions.ResourceNotFoundException;
import com.onlinegrocery.repo.AddressRepo;
import com.onlinegrocery.repo.OrderRepo;
import com.onlinegrocery.service.AddressService;
import com.onlinegrocery.service.OrderService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;


@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/orders")
public class OrderController {
	
	@Autowired
	private OrderService orderservice;
	@Autowired
	private AddressService addressService;
	
	@GetMapping("/username/{username}")
    public List<Order> getOrdersByUsername(@PathVariable String username) {
        return orderservice.getOrderByUsername(username);
    }
	
	@PutMapping("/updateStatus/{orderId}")
	public OrderDto updateStatus(long orderId, Status status )throws OrderNotFoundException{
		return orderservice.updateStatus(orderId, status);
	}

	//Cancel Order
	@DeleteMapping("/cancelOrder/{orderId}")
	public String cancelOrder(@PathVariable long orderId) throws OrderNotFoundException {
		String cancelOrder = this.orderservice.cancelOrder(orderId);
		return cancelOrder;
	}

	//View Order
	@GetMapping("/viewOrder")
	public List<Order> viewOrder() {
		List<Order> viewOrder = this.orderservice.viewOrder();
	return viewOrder;
}
	@PostMapping("/createOrder")
	public String createOrder(@RequestBody OrderDto orderDto) {
		return orderservice.createOrder(orderDto);
		
	}
	
	@GetMapping("/viewOrderByStatus")
	public List<Order> vieworderbyStatus(Status status)throws OrderNotFoundException{
	return orderservice.vieworderbyStatus(status);

	}
	 
	
	
}

