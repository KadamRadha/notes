package com.onlinegrocery.service;

import java.util.List;

import com.onlinegrocery.dto.ProductDto;
import com.onlinegrocery.entity.Product;
import com.onlinegrocery.enums.Category;



public interface ProductService {
	String addProduct(Product product);
	String deleteProduct(long producId);
	List<Product> getAllProducts();
	List<Product> getProductByCategory(Category category);
	//Product updateProduct(Product product);
	Product getById(long productId);
	String updateProduct(ProductDto product, long productid);
}
